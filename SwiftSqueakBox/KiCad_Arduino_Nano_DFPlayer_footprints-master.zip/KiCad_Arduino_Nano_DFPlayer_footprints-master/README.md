# KiCad_Arduino_Nano_DFPlayer_footprints
Footprints for Arduino Nano and DFPlayer MP3 player because I had to make them. 

(I actually use a 32 pin socket to hold the nano to the board. eBay: 32 pin dip IC socket. 2x16.)

There are already components out there for both, but I couldnt find a footprint.


## How
* Add to your library directory.
  * mine was: C:\Program Files\KiCad\share\kicad\library
* Add library to Cvpcb app. Preferences->footprint libraries-> append with wizard
